SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `auth_group` (`id`, `name`) VALUES
(3, 'Cajero'),
(4, 'Cliente'),
(1, 'Gerente'),
(2, 'Veterinario');

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `auth_group_permissions` (`id`, `group_id`, `permission_id`) VALUES
(2, 1, 29),
(3, 1, 30),
(4, 1, 31),
(1, 1, 32),
(5, 2, 41),
(6, 2, 42),
(7, 2, 43),
(8, 2, 44),
(17, 3, 25),
(18, 3, 26),
(19, 3, 27),
(20, 3, 28),
(9, 3, 33),
(10, 3, 34),
(11, 3, 35),
(12, 3, 36),
(13, 3, 37),
(14, 3, 38),
(15, 3, 39),
(16, 3, 40);

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add orden', 7, 'add_orden'),
(26, 'Can change orden', 7, 'change_orden'),
(27, 'Can delete orden', 7, 'delete_orden'),
(28, 'Can view orden', 7, 'view_orden'),
(29, 'Can add producto', 8, 'add_producto'),
(30, 'Can change producto', 8, 'change_producto'),
(31, 'Can delete producto', 8, 'delete_producto'),
(32, 'Can view producto', 8, 'view_producto'),
(33, 'Can add pedido', 9, 'add_pedido'),
(34, 'Can change pedido', 9, 'change_pedido'),
(35, 'Can delete pedido', 9, 'delete_pedido'),
(36, 'Can view pedido', 9, 'view_pedido'),
(37, 'Can add orden pedido', 10, 'add_ordenpedido'),
(38, 'Can change orden pedido', 10, 'change_ordenpedido'),
(39, 'Can delete orden pedido', 10, 'delete_ordenpedido'),
(40, 'Can view orden pedido', 10, 'view_ordenpedido'),
(41, 'Can add cita', 11, 'add_cita'),
(42, 'Can change cita', 11, 'change_cita'),
(43, 'Can delete cita', 11, 'delete_cita'),
(44, 'Can view cita', 11, 'view_cita');

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$180000$stwxcW6S9VN8$gK3/BDII/bH5FJwD2HhUDJakcBYJ1DpuicXTXT2SRZ0=', '2020-06-07 03:19:37.564670', 1, 'admin', '', '', 'isaac.v.moreno@gmail.com', 1, 1, '2020-06-07 03:19:20.706680'),
(2, 'pbkdf2_sha256$180000$p30d4AvyvWic$QlsvUFriFjqo+ZBg3/ur9ONr2Y1JAqjOzgfBPtBZLqI=', NULL, 0, 'juanito', '', '', '', 0, 1, '2020-06-07 03:40:24.000000'),
(3, 'pbkdf2_sha256$180000$AvKPhUbQANl2$/d9wVbLecbaz1OU2rV20A/fsZ1OICfMCm3pPl8ciF1k=', NULL, 0, 'veterinario', '', '', '', 1, 1, '2020-06-07 03:41:45.000000'),
(4, 'pbkdf2_sha256$180000$RKhXdfXxuofj$iHd46ydtarMscfzYFpHC9zPcCXCQnTnxuIA5/+asJd8=', NULL, 0, 'gerente', '', '', '', 1, 1, '2020-06-07 03:42:09.000000'),
(5, 'pbkdf2_sha256$180000$oRjsynEDbbuC$ysW2t4Cf+j6wfdan7XGR+8BBkjqLmku/gfB7VbFPK1c=', NULL, 0, 'caja', '', '', '', 1, 1, '2020-06-07 03:42:38.000000');

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `auth_user_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 2, 4),
(2, 3, 2),
(3, 4, 1),
(4, 5, 3);

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2020-06-07 03:20:17.861389', '1', 'Gerente', 1, '[{\"added\": {}}]', 3, 1),
(2, '2020-06-07 03:20:30.223199', '2', 'Veterinario', 1, '[{\"added\": {}}]', 3, 1),
(3, '2020-06-07 03:20:43.507386', '3', 'Cajero', 1, '[{\"added\": {}}]', 3, 1),
(4, '2020-06-07 03:20:50.476066', '4', 'Cliente', 1, '[{\"added\": {}}]', 3, 1),
(5, '2020-06-07 03:21:39.952981', '1', 'Producto object (1)', 1, '[{\"added\": {}}]', 8, 1),
(6, '2020-06-07 03:22:47.193294', '2', 'Producto object (2)', 1, '[{\"added\": {}}]', 8, 1),
(7, '2020-06-07 03:40:24.297322', '2', 'juanito', 1, '[{\"added\": {}}]', 4, 1),
(8, '2020-06-07 03:40:47.994951', '2', 'juanito', 2, '[{\"changed\": {\"fields\": [\"Groups\"]}}]', 4, 1),
(9, '2020-06-07 03:41:46.061645', '3', 'veterinario', 1, '[{\"added\": {}}]', 4, 1),
(10, '2020-06-07 03:41:55.609408', '3', 'veterinario', 2, '[{\"changed\": {\"fields\": [\"Staff status\", \"Groups\"]}}]', 4, 1),
(11, '2020-06-07 03:42:10.221332', '4', 'gerente', 1, '[{\"added\": {}}]', 4, 1),
(12, '2020-06-07 03:42:18.301148', '4', 'gerente', 2, '[{\"changed\": {\"fields\": [\"Staff status\", \"Groups\"]}}]', 4, 1),
(13, '2020-06-07 03:42:38.655496', '5', 'caja', 1, '[{\"added\": {}}]', 4, 1),
(14, '2020-06-07 03:42:46.325168', '5', 'caja', 2, '[{\"changed\": {\"fields\": [\"Staff status\", \"Groups\"]}}]', 4, 1),
(15, '2020-06-07 03:43:37.040025', '1', 'Cita object (1)', 1, '[{\"added\": {}}]', 11, 1),
(16, '2020-06-07 04:06:00.683794', '1', 'Pedido object (1)', 1, '[{\"added\": {}}]', 9, 1),
(17, '2020-06-07 04:07:27.187534', '1', 'Orden object (1)', 1, '[{\"added\": {}}]', 7, 1),
(18, '2020-06-07 04:14:00.808928', '1', 'OrdenPedido object (1)', 1, '[{\"added\": {}}]', 10, 1);

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(11, 'HuellitasApp', 'cita'),
(7, 'HuellitasApp', 'orden'),
(10, 'HuellitasApp', 'ordenpedido'),
(9, 'HuellitasApp', 'pedido'),
(8, 'HuellitasApp', 'producto'),
(6, 'sessions', 'session');

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2020-06-07 03:18:40.548854'),
(2, 'auth', '0001_initial', '2020-06-07 03:18:40.895696'),
(3, 'HuellitasApp', '0001_initial', '2020-06-07 03:18:42.142683'),
(4, 'admin', '0001_initial', '2020-06-07 03:18:42.932261'),
(5, 'admin', '0002_logentry_remove_auto_add', '2020-06-07 03:18:43.176292'),
(6, 'admin', '0003_logentry_add_action_flag_choices', '2020-06-07 03:18:43.199291'),
(7, 'contenttypes', '0002_remove_content_type_name', '2020-06-07 03:18:43.471295'),
(8, 'auth', '0002_alter_permission_name_max_length', '2020-06-07 03:18:43.516298'),
(9, 'auth', '0003_alter_user_email_max_length', '2020-06-07 03:18:43.553289'),
(10, 'auth', '0004_alter_user_username_opts', '2020-06-07 03:18:43.567295'),
(11, 'auth', '0005_alter_user_last_login_null', '2020-06-07 03:18:43.713857'),
(12, 'auth', '0006_require_contenttypes_0002', '2020-06-07 03:18:43.721896'),
(13, 'auth', '0007_alter_validators_add_error_messages', '2020-06-07 03:18:43.741869'),
(14, 'auth', '0008_alter_user_username_max_length', '2020-06-07 03:18:43.779906'),
(15, 'auth', '0009_alter_user_last_name_max_length', '2020-06-07 03:18:43.818461'),
(16, 'auth', '0010_alter_group_name_max_length', '2020-06-07 03:18:43.858788'),
(17, 'auth', '0011_update_proxy_permissions', '2020-06-07 03:18:43.876787'),
(18, 'sessions', '0001_initial', '2020-06-07 03:18:43.932583');

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('wsua5youdga2nj6ut3utkddb3vzweyi4', 'YjE3ODg4ZGExY2Y1Mjk1YjFlNjhkMTZlYmRkODM1OThjN2M4MTgyMjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1ZGJiYjNmYzc3ZjdlOGQwNzc2MjcxNGQyNjQ4M2M2OTJlZjU4MDQ3In0=', '2020-06-21 03:19:37.572661');

CREATE TABLE `huellitasapp_cita` (
  `id` int(11) NOT NULL,
  `fec_cita` date NOT NULL,
  `est_cita` varchar(20) NOT NULL,
  `id_clie_id` int(11) NOT NULL,
  `id_vete_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `huellitasapp_cita` (`id`, `fec_cita`, `est_cita`, `id_clie_id`, `id_vete_id`) VALUES
(1, '2020-06-12', 'En espera', 2, 3);

CREATE TABLE `huellitasapp_orden` (
  `id` int(11) NOT NULL,
  `total_ord` decimal(9,2) NOT NULL,
  `pago_ord` tinyint(1) NOT NULL,
  `envio_ord` tinyint(1) NOT NULL,
  `fec_ord` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `huellitasapp_orden` (`id`, `total_ord`, `pago_ord`, `envio_ord`, `fec_ord`) VALUES
(1, '79.80', 1, 0, '2020-06-06');

CREATE TABLE `huellitasapp_ordenpedido` (
  `id` int(11) NOT NULL,
  `id_ord_id` int(11) NOT NULL,
  `id_ped_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `huellitasapp_ordenpedido` (`id`, `id_ord_id`, `id_ped_id`) VALUES
(1, 1, 1);

CREATE TABLE `huellitasapp_pedido` (
  `id` int(11) NOT NULL,
  `can_ped` int(11) NOT NULL,
  `id_pro_id` int(11) NOT NULL,
  `id_usu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `huellitasapp_pedido` (`id`, `can_ped`, `id_pro_id`, `id_usu_id`) VALUES
(1, 2, 1, 2);

CREATE TABLE `huellitasapp_producto` (
  `id` int(11) NOT NULL,
  `mod_producto` varchar(30) NOT NULL,
  `id_tipo` varchar(50) NOT NULL,
  `id_color` varchar(50) NOT NULL,
  `id_mat` varchar(50) NOT NULL,
  `id_ori` varchar(20) NOT NULL,
  `id_mar` varchar(50) NOT NULL,
  `pre_uni` decimal(9,2) NOT NULL,
  `stock_pro` int(11) NOT NULL,
  `img_pro` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `huellitasapp_producto` (`id`, `mod_producto`, `id_tipo`, `id_color`, `id_mat`, `id_ori`, `id_mar`, `pre_uni`, `stock_pro`, `img_pro`, `created_at`, `updated_at`) VALUES
(1, '15-da0019la', 'Alimento', 'Rojo', 'Orgánico', 'Importado', 'Whiskas', '39.90', 4, '/statics/images-site/pets/02.jpg', '2020-06-06', '2020-06-06'),
(2, '11-d1001dc', 'Accesorio', 'Negro', 'Plástico', 'Chino', 'Pets happy', '50.25', 2, '/statics/images-site/pets/02.jpg', '2020-06-06', '2020-06-06');


ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

ALTER TABLE `huellitasapp_cita`
  ADD PRIMARY KEY (`id`),
  ADD KEY `HuellitasApp_cita_id_clie_id_3a62aa60_fk_auth_user_id` (`id_clie_id`),
  ADD KEY `HuellitasApp_cita_id_vete_id_ab705fc0_fk_auth_user_id` (`id_vete_id`);

ALTER TABLE `huellitasapp_orden`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `huellitasapp_ordenpedido`
  ADD PRIMARY KEY (`id`),
  ADD KEY `HuellitasApp_ordenpe_id_ord_id_2856dfcd_fk_Huellitas` (`id_ord_id`),
  ADD KEY `HuellitasApp_ordenpe_id_ped_id_98615cc8_fk_Huellitas` (`id_ped_id`);

ALTER TABLE `huellitasapp_pedido`
  ADD PRIMARY KEY (`id`),
  ADD KEY `HuellitasApp_pedido_id_pro_id_40267b38_fk_Huellitas` (`id_pro_id`),
  ADD KEY `HuellitasApp_pedido_id_usu_id_a8fc3f0c_fk_auth_user_id` (`id_usu_id`);

ALTER TABLE `huellitasapp_producto`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

ALTER TABLE `huellitasapp_cita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `huellitasapp_orden`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `huellitasapp_ordenpedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `huellitasapp_pedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `huellitasapp_producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;


ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

ALTER TABLE `huellitasapp_cita`
  ADD CONSTRAINT `HuellitasApp_cita_id_clie_id_3a62aa60_fk_auth_user_id` FOREIGN KEY (`id_clie_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `HuellitasApp_cita_id_vete_id_ab705fc0_fk_auth_user_id` FOREIGN KEY (`id_vete_id`) REFERENCES `auth_user` (`id`);

ALTER TABLE `huellitasapp_ordenpedido`
  ADD CONSTRAINT `HuellitasApp_ordenpe_id_ord_id_2856dfcd_fk_Huellitas` FOREIGN KEY (`id_ord_id`) REFERENCES `huellitasapp_orden` (`id`),
  ADD CONSTRAINT `HuellitasApp_ordenpe_id_ped_id_98615cc8_fk_Huellitas` FOREIGN KEY (`id_ped_id`) REFERENCES `huellitasapp_pedido` (`id`);

ALTER TABLE `huellitasapp_pedido`
  ADD CONSTRAINT `HuellitasApp_pedido_id_pro_id_40267b38_fk_Huellitas` FOREIGN KEY (`id_pro_id`) REFERENCES `huellitasapp_producto` (`id`),
  ADD CONSTRAINT `HuellitasApp_pedido_id_usu_id_a8fc3f0c_fk_auth_user_id` FOREIGN KEY (`id_usu_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
